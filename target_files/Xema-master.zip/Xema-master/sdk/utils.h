#pragma once

#ifdef _MSC_VER
#include <Windows.h>
#endif // _MSC_VER


void log();